#include "stdafx.h"
#include "SceneTitle.h"

SceneTitle::SceneTitle()
	: Scene(SceneIds::Title)
{

}

void SceneTitle::Init()
{

}

void SceneTitle::Update(float dt)
{

}
