#include "stdafx.h"
#include "Log.h"

Log::Log(const std::string& name)
	:GameObject(name)
{
}

void Log::SetPosition(const sf::Vector2f& pos)
{
	position = pos;
	for (int i = 0; i < logs.size(); ++i)
	{
		logs[i].setPosition(pos);
	}
}

void Log::Init()
{
	texIdLog = "graphics/log.png";
}

void Log::Release()
{
}

void Log::Reset()
{
	
	logs.resize(5);
	logVelocity.resize(5);
	isLogActive.resize(5);
	logDirection.resize(5);

	for (int i = 0; i < logs.size(); i++)
	{
		logs[i].setTexture(TEXTURE_MGR.Get(texIdLog));
		logDirection[i] = { 1.f,-1.f };
		logVelocity[i] = logDirection[i] * logSpeed;
		isLogActive[i] = false;
	}

}

void Log::Update(float dt)
{
	if (InputMgr::GetKeyDown(sf::Keyboard::Left))
	{
		isLogActive[logIdxCount] = true;
		logDirection[logIdxCount].x = 1.f;
		logVelocity[logIdxCount] = logDirection[logIdxCount] * logSpeed;
		logIdxCount++;
		std::cout << "log Right" << logIdxCount << std::endl;
	}
	if (InputMgr::GetKeyDown(sf::Keyboard::Right))
	{
		
		isLogActive[logIdxCount] = true;
		logDirection[logIdxCount].x = -1.f;
		logVelocity[logIdxCount] = logDirection[logIdxCount] * logSpeed;
		logIdxCount++;
		std::cout << "log Right" << logIdxCount << std::endl;
	}
	for (int i = 0; i < logs.size(); i++)
	{
		logVelocity[i] += gravity * dt;
		position = logs[i].getPosition();
		position += logVelocity[i] * dt;
		logs[i].setPosition(position);
	}
	if (logIdxCount == 5)
	{
		logIdxCount = 0;
	}
	
}

void Log::Draw(sf::RenderWindow& window)
{
	for (int i = 0; i < logs.size(); i++)
	{
		if (isLogActive[i])
		{
			window.draw(logs[i]);
		}
	}
}
